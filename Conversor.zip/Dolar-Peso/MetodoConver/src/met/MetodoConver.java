//Eduardo Martinez Becerra
package met;

/**
 *
 * Eduardo Martinez Becerra
 */
public class MetodoConver {
    
    public double multiplicacion(double num1){
        return num1 * 20;
    }
    
    public double division(double num1){
        return num1 / 20;
    }
}
